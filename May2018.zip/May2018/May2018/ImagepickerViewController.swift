//
//  ImagepickerViewController.swift
//  May2018
//
//  Created by agilemac-74 on 20/06/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit
 
class ImagepickerViewController: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate {

    @IBOutlet var imgPreview: UIImageView!
    
     let picker = UIImagePickerController()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        picker.delegate = self
    }
    
   
    
    func photoFromLibrary(isCamera:Bool)
    {
        picker.allowsEditing = true   // true
        
        if isCamera
        {
            picker.sourceType = .camera
        }
        else
        {
            picker.sourceType = .photoLibrary
        }
        picker.mediaTypes = UIImagePickerController.availableMediaTypes(for: .photoLibrary)!
        present(picker, animated: true, completion: nil)
    }
    
    //MARK: - Delegates
    public func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any])
    {
        print(info)
        
        let chosenImage = info[UIImagePickerControllerOriginalImage] as! UIImage //2
        let editedImage = info[UIImagePickerControllerEditedImage] as! UIImage
        
         imgPreview.contentMode = .scaleAspectFit //3
        //imgPreview.image = editedImage //4
        
        imgPreview.image = editedImage
        
        dismiss(animated:true, completion: nil) //5
        
        
    }
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
    
    
    
    @IBAction func selectPhoto(_ sender: UIButton) {
        
        let alert = UIAlertController(title: "Photo", message: "Please Choose Source Type", preferredStyle: .actionSheet)
        
        alert.addAction(UIAlertAction(title: "Camera", style: .default, handler: { (action) in
            //execute some code when this option is selected
            self.photoFromLibrary(isCamera: true)
            
        }))
        alert.addAction(UIAlertAction(title: "Photo Library", style: .default, handler: { (action) in
            //execute some code when this option is selected
            
            self.photoFromLibrary(isCamera: false)
            
        }))
        
        self.present(alert, animated: true, completion: nil)
        
    }

   
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
