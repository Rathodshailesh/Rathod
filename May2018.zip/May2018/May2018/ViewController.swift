//
//  ViewController.swift
//  May2018
//
//  Created by agilemac-74 on 07/05/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITextFieldDelegate,testProtocol,UITextViewDelegate {
    
    @IBOutlet var btnSave: UIButton!
    
    @IBOutlet var txtEmail: UITextField!
    
    @IBOutlet var txtName: UITextField!
    
    
    var arrStudentInfo = [[String:Any]]()
    
    @IBOutlet var lblCount: UILabel!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        
        txtName.delegate = self
        
        
        
        
       // test()
        let answer = addition(a: 5, b: 5, type: "*")
        
        print("\(answer.0) = \(answer.1)")
        
        
        print("viewDidLoad")
        
        let a = ""
        
       // a = 5
        
        //a = "xyz"
        
        var b = "abc"
        
        print(b)
        b = "xyz"
        
        
        print(a)
        print(b)
        
        //var a1:String = ""
        
        var a1:String! = "abc"
        
        a1 = nil
        
        var test:String? = "abcde.."
        
        test = nil
        
        if let tmp = test
        {
            print(tmp)
            print(test!)
        }
        else
        {
            print("Null Value")
        }
        
        
        
        let arrStudent = ["abc","xyz","efg"]
        
        print(arrStudent.count)
        print(arrStudent[0])
        var arrDynamic = [String]()
        
        arrDynamic.append("abc")
        arrDynamic.append("abc1")
        arrDynamic.append("abc2")
        arrDynamic.append("abc3")
        
        
        arrDynamic.insert("mnp", at: 2)
        arrDynamic.remove(at: 0)
        arrDynamic.removeAll()
        
        print(arrDynamic)
        
        
        let dic = ["fName":"Agile","lName":"Infoways"]
        
        
        print(dic["fName"])
        print(dic["lName"])
        
        var dicDynamic = [String:Any]()
        
        dicDynamic["fName"] = "agileTest"
        dicDynamic["lName"] = "infowaysTest"
        dicDynamic["mobile"] = 1122323235
        dicDynamic["email"] = "asdasda"
        
         dicDynamic["email"] = "123564"
        
        print(dicDynamic)
        
        
        print(dicDynamic["mobile"])
        
        
        let lbl = UILabel(frame: CGRect(x: 50, y: 100, width: 180, height: 30))
        
        lbl.text = "Agile Infoways"
        lbl.textColor = UIColor.white
        lbl.backgroundColor = UIColor.orange
        
        lbl.numberOfLines = 1
        
        self.view.addSubview(lbl)

        
        //var a1:String = nil
        
        //print(a)
        
        
        txtName.text = "Agile Infoways"
        
        let fName = txtName.text
        
        
        txtName.becomeFirstResponder()
        
        
        
        // Define identifier
        let notificationName = Notification.Name("NotificationIdentifier")
        
        
        
        // Register to receive notification
        NotificationCenter.default.addObserver(self, selector: #selector(ViewController.methodOfReceivedNotification), name: notificationName, object: nil)
        
       
        
      
        
       
        
    }
    
    @objc func methodOfReceivedNotification(_ notification: Notification)
    {
        print("call methodOfReceivedNotification...")
        
        
        //let info0 = notification.userInfo?["test"]
       
        
        var count = Int(lblCount.text!)
        count = count! + 1
        lblCount.text = String(count!)
        
    }
    
    func testMethod(value: String) {
        print("call delegate methods...\(value)")
        
        var count = Int(lblCount.text!)
        count = count! + 1
        lblCount.text = String(count!)
        
        
        
    }
        
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        
    }
    func textViewDidEndEditing(_ textView: UITextView) {
        
    }
    
    
    //MARK:- Button click
    @IBAction func saveClick(_ sender: UIButton) {
        
        let fName = txtName.text!
        let email = txtEmail.text!
        
        
        let dic = ["firstName" : fName,"Email":email]
        
    
        
        arrStudentInfo.append(dic)
        
        
        print(arrStudentInfo)
        
        if arrStudentInfo.count == 2
        {
            // push to detail vc
            
            
            for i in 0..<arrStudentInfo.count
            {
                let dic = arrStudentInfo[i]
                
                
                let fName = dic["firstName"]
                let email = dic["Email"]
                
                print(email)
                print(fName)
                
            }

        }
        else
        {
            txtEmail.text = ""
            txtName.text = ""
        }
        
        
    }
    
    
    //MARK:- Uitextfield delegate methods
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        
        
        
        
        print("textFieldShouldBeginEditing")
        
        if textField == txtEmail
        {
            textField.keyboardType = .emailAddress
        }
        else
        {
            textField.keyboardType = .default
        }
        
        
        return  true
        
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        
        print("textFieldDidEndEditing")
        
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        
        textField.resignFirstResponder()
        
        return true
    }
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        
        print(string)
        
        return true
    }
    
    
    
    @IBAction func submitClick(_ sender: UIButton) {
        
        
        print(sender.tag)
        if sender.tag == 0
        {
            // submit
        }
        else
        {
            // test
        }
        
        // To fetch storyboard objet
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        
        // To fetch Login VC object from storyboard
        let loginVC = storyBoard.instantiateViewController(withIdentifier: "loginViewController") as! loginViewController
        
        // Pass data to the VC before pushing
        loginVC.getData = "abcdefdfjsdjf"
       // loginVC.getStudentInfo = arrStudentInfo
        
        loginVC.delegate = self
        
        // Push the View controller using navigation controller
        self.navigationController?.pushViewController(loginVC, animated: true)
        
        
        
    }
    override func viewWillAppear(_ animated: Bool) {
        
        self.navigationController?.navigationBar.isHidden = true
        
        print("viewWillAppear")
        
        let userDefault = UserDefaults.standard
        
        userDefault.set(txtName.text!, forKey: "userName")
        
        
        
    }
    override func viewDidAppear(_ animated: Bool) {
        
        print("viewDidAppear")
        
        
       
        
        
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        
         print("viewWillDisappear")
    }
    override func viewDidDisappear(_ animated: Bool) {
        
        print("viewDidDisappear")
        
    }
    
    
    func addition(a:Int,b:Int,type:String) ->(String,Int)
    {
        
        if type == "+"
        {
            return("Addition",a+b)
        }
        if type == "-"
        {
            return("Subtraction",a - b)
        }
        if type == "*"
        {
            return("Multi",a * b)
        }
        
        return("",0)
    }
    
    
    
    func test()
    {
        print("test called...")
    }
    
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        
        if segue.identifier == "signIn"
        {
            let loginvc = segue.destination as! loginViewController
        
            loginvc.getData = "123456"
        }
        else if segue.identifier == "signUp"
        {
            
        }
        
        
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

