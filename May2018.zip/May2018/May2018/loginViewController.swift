//
//  loginViewController.swift
//  May2018
//
//  Created by agilemac-74 on 07/05/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit



protocol testProtocol {
    
    func testMethod(value:String)
    
}

class loginViewController: UIViewController,UITextFieldDelegate {
    
    @IBOutlet var btnSignIn: UIButton!
    
    var delegate:testProtocol?
    
    
    @IBOutlet var txtMobile: UITextField!
    @IBOutlet var scrlView: UIScrollView!
    var getData = ""
    
    @IBOutlet var txtEmail: UITextField!
    var getStudentInfo = [[String:Any]]()
    
    @IBOutlet var txtFName: UITextField!
    
    @IBOutlet var txtLName: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        
        print(getData)
      
        scrlView.contentSize = CGSize(width: scrlView.frame.size.width, height: 850)
        
        
        print("login viewDidLoad")
        
        self.navigationController?.navigationBar.isHidden = true
        
    }
    
    
    
    @IBAction func signInClick(_ sender: UIButton) {
        
        
        // To fetch storyboard objet
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        
        // To fetch Login VC object from storyboard
        let signUP = storyBoard.instantiateViewController(withIdentifier: "signUpViewController") as! signUpViewController
        
      
        self.navigationController?.pushViewController(signUP, animated: true)
    }
    
    @IBAction func backClick(_ sender: UIButton) {
        
        // POP a view controller (remove)
        self.navigationController?.popViewController(animated: true)
        
        
    }
    override func viewWillAppear(_ animated: Bool) {

        print("login viewWillAppear")
        
    }
    override func viewDidAppear(_ animated: Bool) {
        
        print("login viewDidAppear")
        
        delegate?.testMethod(value: "")
        
        
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        
        print("login viewWillDisappear")
        
    }
    override func viewDidDisappear(_ animated: Bool) {
        print("login viewDidDisappear")
        
    }
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        
        if textField == txtEmail ||  textField == txtMobile
        {
            scrlView.contentOffset = CGPoint(x: 0, y: 200)
        }
        
        
        return true
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool
    {
        
        textField.resignFirstResponder()
        scrlView.contentOffset = CGPoint(x: 0, y: 0)
        return true
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    

}
