//
//  tbldemoViewController.swift
//  May2018
//
//  Created by agilemac-74 on 01/06/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit

class tbldemoViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    @IBOutlet var viewHeader: UIView!
    @IBOutlet var tblList: UITableView!
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.tblList.register(UINib(nibName: "studentTextViewTableViewCell", bundle: nil), forCellReuseIdentifier: "studentTextViewTableViewCell")
        
        
        tblList.tableFooterView = viewHeader
        
        
    }
    
    //MARK:- tableview delegate and datasource methods
    func numberOfSections(in tableView: UITableView) -> Int {
        return 4
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        
        if section == 0
        {
            return "India"
        }
        else if section == 1
        {
            return "USA"
        }
        else
        {
            return "Other"
        }
        
        
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 40
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        
        return 40
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let view = UIView()
        let lbl = UILabel()
        lbl.text = "asdds"
        view.addSubview(lbl)
        view.backgroundColor = UIColor.red
        return view
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0
        {
            return 5
        }
        else if section == 1
        {
            return 3
        }
        else
        {
            return 2
        }
        
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! studentTableViewCell
        
       cell.lblFirstName.text = "First Name"
        cell.lblLastName.text = "Last Name"
        cell.lblEmail.text = "test@test.com"
        
        return cell
        
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        print(indexPath.row)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        /*
        if indexPath.row == 4
        {
            return 150
        }
 */
            return 100
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
