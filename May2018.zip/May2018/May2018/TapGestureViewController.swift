//
//  HomeViewController.swift
//  May2018
//
//  Created by agilemac-74 on 02/07/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit

class TapGestureViewController: UIViewController {
    
    @IBOutlet var pinchView: UIView!
    @IBOutlet var rotateView: UIView!
    @IBOutlet var panView: UIView!
    
    @IBOutlet var testView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        /*
        let singleTapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(handleSingleTapGesture))
        
        testView.addGestureRecognizer(singleTapGestureRecognizer)
        
        
        
        let doubleTapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(handleDoubleTapGesture))
        
        // view.addGestureRecognizer(tap)
        doubleTapGestureRecognizer.numberOfTapsRequired = 2
        
        //doubleTapGestureRecognizer.numberOfTouchesRequired = 2
        
       testView.addGestureRecognizer(doubleTapGestureRecognizer)
        
        */
        /*
        let swipeGesture = UISwipeGestureRecognizer(target: self, action: #selector(swipeGestureSelection(swipeGesture:)))
        swipeGesture.direction = .down
        */
        
        
        
        
        //testView.addGestureRecognizer(swipeGesture)
        
        
        let panGestureRecognizer = UIPanGestureRecognizer(target: self, action: #selector(panGestureSelection(panGesture:)))
        
        panView.addGestureRecognizer(panGestureRecognizer)
        
        
        let rotateGestureRecognizer = UIRotationGestureRecognizer(target: self, action: #selector(rotateGestureSelection(rotateGesture:)))
        
        rotateView.addGestureRecognizer(rotateGestureRecognizer)
        
        
        let pinchGestureRecognizer = UIPinchGestureRecognizer(target: self, action: #selector(pinchGestureSelection(pinchGesture:)))
        
        pinchView.addGestureRecognizer(pinchGestureRecognizer)
        
    }
    
    @objc func swipeRightGestureSelection(swipeGesture:UISwipeGestureRecognizer)
    {
        
        
    }
    
    @objc func swipeLeftGestureSelection(swipeGesture:UISwipeGestureRecognizer)
    {
        
        
    }
    
    @objc func pinchGestureSelection(pinchGesture:UIPinchGestureRecognizer)
    {
        self.pinchView.transform = self.pinchView.transform.scaledBy(x: pinchGesture.scale, y: pinchGesture.scale);
        
        pinchGesture.scale = 1.0;
        
        
    }
    
    @objc func rotateGestureSelection(rotateGesture:UIRotationGestureRecognizer)
    {
        
        self.rotateView.transform = self.rotateView.transform.rotated(by: rotateGesture.rotation);
        
        rotateGesture.rotation = 0.0;
        
    }
    
    
    @objc func panGestureSelection(panGesture:UIPanGestureRecognizer)
    {
        
        print("pan gesture called")
        
        let touchLocation:CGPoint = panGesture.location(in: self.view)
        
        self.panView.center = touchLocation
        
        let velocity:CGPoint = panGesture.velocity(in: self.view)
        
        print(velocity)
        
    }
    
    @objc func handleDoubleTapGesture(tapGestureRecognizer:UITapGestureRecognizer)
    {
        
        var newSize:CGSize = CGSize(width: 100.0, height: 100.0) //CGSizeMake(100.0, 100.0);
        
        if (self.testView.frame.size.width == 100.0)
        {
            newSize.width = 200.0;
            newSize.height = 200.0;
        }
        
        let currentCenter:CGPoint = self.testView.center;
        
        self.testView.frame = CGRect(x: self.testView.frame.origin.x, y: self.testView.frame.origin.y, width: newSize.width, height: newSize.height) //CGRectMake(self.testView.frame.origin.x, self.testView.frame.origin.y, newSize.width, newSize.height);
        self.testView.center = currentCenter;
        
    }
    
    
    
    @objc func handleSingleTapGesture(tapGestureRecognizer:UITapGestureRecognizer)
    {
        var newWidth:CGFloat = 100.0
        
        if(self.testView.frame.size.width == 100.0)
        {
            newWidth = 200.0
        }
        
        let currentCenter:CGPoint = self.testView.center
        
        self.testView.frame = CGRect(x: self.testView.frame.origin.x, y: self.testView.frame.origin.y, width: newWidth, height: self.testView.frame.size.height) //CGRectMake(self.testView.frame.origin.x, self.testView.frame.origin.y, newWidth, self.testView.frame.size.height);
        
        self.testView.center = currentCenter;
        
    }
    
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
