//
//  DBViewController.swift
//  May2018
//
//  Created by agilemac-74 on 25/07/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit
import FMDB

class DBViewController: UIViewController {
    
    
    var database:FMDatabase? = nil
    
    
    @IBOutlet var txtFirstName: UITextField!
    
    @IBOutlet var txtLastName: UITextField!
    
    @IBOutlet var txtEmail: UITextField!
    
    @IBOutlet var txtCity: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        let documentsURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        
        let fileURL = documentsURL.appendingPathComponent("AgileDB.sqlite" as String)
        
       database = FMDatabase(path: fileURL.path)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func submitClick(_ sender: UIButton) {
        
        
        let getAllUserData = ModelManager.getInstance().getAllData()
        
        
        print(getAllUserData.count)
        
        
        
        for i in 0..<getAllUserData.count
        {
            let dic = getAllUserData[i]
            
            print(dic)
        }
        
        
        return
        
        
        let firstName = txtFirstName.text!
        let lastName = txtLastName.text!
        let email = txtEmail.text!
        let city = txtCity.text!
        
        
        
        /*
        let isInsert = ModelManager.getInstance().InsertData(name: firstName, lastName: lastName, email: email, city: city)
        
        print(isInsert)
        */
        
        database!.open()
        
        
        let isInserted = database!.executeUpdate("INSERT INTO tbl_User (firstName, lastName,email,city) VALUES (?,?,?,?)", withArgumentsIn: [firstName,lastName,email,city]);
        
        print(database!.lastErrorMessage())
        
       database!.close()
        
        
        print(isInserted)
        
        
        
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
