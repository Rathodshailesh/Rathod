//
//  collectionViewController.swift
//  May2018
//
//  Created by agilemac-74 on 27/06/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit

class collectionViewController: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout {

    @IBOutlet var colView: UICollectionView!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        
       
        
    }
    
    override func viewDidLayoutSubviews() {
        
        
        let flowLayout = UICollectionViewFlowLayout()
        
        flowLayout.minimumLineSpacing = 5
        flowLayout.minimumInteritemSpacing = 10
        
        flowLayout.sectionInset = UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10)
        
        colView.setCollectionViewLayout(flowLayout, animated: true)
    }
    
    
    
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
    {
        
        //return CGSize(width: 75 , height: 60)
       // let SCREEN_WIDTH = self.view.frame.size.width
        
         let SCREEN_WIDTH = UIScreen.main.bounds.size.width
        
        print(SCREEN_WIDTH)
        
        //  return CGSize(((SCREEN_WIDTH - 30) / 3), ((SCREEN_WIDTH - 30) / 3))
        
        return CGSize(width: floor(((SCREEN_WIDTH - 40) / 3)), height: ((SCREEN_WIDTH - 40) / 3))
        
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return 9
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath)
        
        return cell
        
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        print(indexPath.row)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
