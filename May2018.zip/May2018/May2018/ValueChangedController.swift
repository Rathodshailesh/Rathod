//
//  ValueChangedController.swift
//  May2018
//
//  Created by agilemac-74 on 20/07/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit

class ValueChangedController: UIViewController {
    
    
    @IBOutlet var progressView: UIProgressView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        progressView.progress = 1
        
    }

    @IBAction func switchClick(_ sender: UISwitch) {
        
        print(sender.isOn)
        
        sender.setOn(true, animated: true)
        
    }
    @IBAction func sliderClick(_ sender: UISlider) {
        
        print(sender.value)
        
    }
    @IBAction func stepperClick(_ sender: UIStepper) {
        
        print(sender.value)
        
    }
    @IBAction func segmentClick(_ sender: UISegmentedControl) {
        
        print(sender.selectedSegmentIndex)
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
