//
//  mapViewController.swift
//  May2018
//
//  Created by agilemac-74 on 28/06/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit
import CoreLocation
import MapKit

class mapViewController: UIViewController,CLLocationManagerDelegate,MKMapViewDelegate {

    @IBOutlet var mapView: MKMapView!
    @IBOutlet var lbllongitude: UILabel!
    
    @IBOutlet var lblLatitude: UILabel!
    var locationManager: CLLocationManager = CLLocationManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        
        
        locationManager.delegate = self

        // Ask for Authorisation from the User.
        self.locationManager.requestAlwaysAuthorization()
        
        // For use in foreground
        self.locationManager.requestWhenInUseAuthorization()
        
        if CLLocationManager.locationServicesEnabled()
        {
            locationManager.startUpdatingLocation()
        }
        
        
        
        
        
        // Do any additional setup after loading the view.
        mapView.mapType = MKMapType.standard
        
        
        mapView.delegate = self
        
        // 2)
        let location = CLLocationCoordinate2D(latitude: 23.0225,longitude: 72.5714)
        
        let location2 = CLLocationCoordinate2D(latitude: 22.3072,longitude: 73.1812)
        
        // 3) 1 = 111 km approx
        let span = MKCoordinateSpanMake(0.05, 0.05)//0.05 = 5 km  0.5 = 50km
        let region = MKCoordinateRegion(center: location, span: span)
        mapView.setRegion(region, animated: true)
        
        // 4)
        let annotation = MKPointAnnotation()
        annotation.coordinate = location
        annotation.title = "My Space"
        annotation.subtitle = "Ahmedabad"
        mapView.addAnnotation(annotation)
        
        
        let annotation2 = MKPointAnnotation()
        annotation2.coordinate = location2
        annotation2.title = "Star Bazar"
        annotation2.subtitle = "Baroda"
        mapView.addAnnotation(annotation2)
        
        
    }
    
    @IBAction func getLocation(_ sender: UIButton) {
        
        
        locationManager.startUpdatingLocation()
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        
        let location = locations.last! as CLLocation
        
        let getLat = manager.location?.coordinate.latitude
        let getLong = manager.location?.coordinate.longitude
        
        print(getLat)
        print(getLong)
        
        /* you can use these values*/
        let lat = location.coordinate.latitude
        let long = location.coordinate.longitude
        
        
        lblLatitude.text = String(lat)
        lbllongitude.text = String(long)
        
        
       //print(lat)
        //print(long)
        
        locationManager.stopUpdatingLocation()
        
    }
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        // Don't want to show a custom image if the annotation is the user's location.
        guard !(annotation is MKUserLocation) else {
            return nil
        }
        
        // Better to make this class property
        let annotationIdentifier = "AnnotationIdentifier"
        
        var annotationView: MKAnnotationView?
        annotationView = MKAnnotationView(annotation: annotation, reuseIdentifier: annotationIdentifier)
        //annotationView?.rightCalloutAccessoryView = UIButton(type: .detailDisclosure)
        
        let btn = UIButton(type: .detailDisclosure)
        btn.addTarget(self, action: #selector(btnClick(_:)), for: .touchUpInside)
        annotationView?.rightCalloutAccessoryView = btn
        
        
        annotationView?.canShowCallout = true
        annotationView?.image = UIImage(named: "pinMapD")
        
        
        return annotationView
    }
    
    @objc func btnClick(_ sender:UIButton)
    {
        print("Button Click....")
    }


    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
