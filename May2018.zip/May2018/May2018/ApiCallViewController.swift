//
//  ApiCallViewController.swift
//  May2018
//
//  Created by agilemac-74 on 06/07/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit
import Alamofire


class ApiCallViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
       // apiCallUsingSession()
        
        //makeGetCall()
        
        postApiCall()
        
    }
    
    
    func postApiCall()
    {
        /*
         let headers: HTTPHeaders = [
         "Accept": "application/json",
         ]
         */
        // let params = ["":""]
        
        //http://202.131.123.211/UdgamApi_v4/App_Services/UdgamService.asmx/GetAllTeacherData
        let requestString = "http://202.131.117.90/UdgamApi_v2/App_Services/UdgamService_V8.asmx/CircularNotice" //"http://sandbox.nexusecare.com/MyHealthCompanionAPI/api/BookService/servicecategories"
        
        let param = ["sid" : 2011029,"notificationid" : 0] as [String : Any]
        
        //let header = ["key":""]
        
        //Alamofire.reques
        
        
        //let header = ["lang" : "eng"]
        
        Alamofire.request(requestString, method: .post, parameters: param, headers: [:]).responseJSON { (response:DataResponse<Any>) in
            
            switch response.result
            {
            case.success(_):
                if let JSON = response.result.value {
                    print("JSON: \(JSON)")
                    
                    let dic = JSON as? NSDictionary
                    
                    let getArr = dic?.object(forKey: "circularNoticedata") as! NSArray
                    
                    
                    
                }
                
            case.failure(let error):
                print(error.localizedDescription)
            }
        }
        
    }
    
    func makeGetCall() {
        // Set up the URL request
        let todoEndpoint: String = "http://202.131.123.211/UdgamApi_v4/App_Services/UdgamService.asmx/GetAllTeacherData?StudentId=2011111"
        guard let url = URL(string: todoEndpoint) else {
            print("Error: cannot create URL")
            return
        }
        var urlRequest = URLRequest(url: url)
        
        urlRequest.httpMethod = "GET"
        
        // set up the session
        let config = URLSessionConfiguration.default
        let session = URLSession(configuration: config)
        
        // make the request
        let task = session.dataTask(with: urlRequest)
        {
            (data, response, error) in
            // check for any errors
            guard error == nil else {
                print("error calling GET on /todos/1")
                print(error)
                return
            }
            // make sure we got data
            guard let responseData = data else {
                print("Error: did not receive data")
                return
            }
            // parse the result as JSON, since that's what the API provides
            do {
                
                
                
                guard let todo = try JSONSerialization.jsonObject(with: responseData, options: []) as? [String: AnyObject] else {
                    print("error trying to convert data to JSON")
                    return
                }
                // now we have the todo, let's just print it to prove we can access it
                
                print(todo as NSDictionary)
                //print("The todo is: " + todo.description)
                
                let dic = todo as NSDictionary
                
                let arr = dic.object(forKey: "teacherDetail") as! [[String:Any]]
                
                
                
                //cell for row
                
                //let dic = arr[indexPath.row]
                
                //lbl.text = dic["TeacherName"] as? String
                
                //let dic = arr[0] as
                
                if let dic = arr[0] as? [String:Any]
                {
                    
                    print(dic["TeacherName"])
                }
                
                
                /*
                let arrTeacher = dic.object(forKey: "teacherDetail") as! NSArray
                
                let dicTeacher = arrTeacher.object(at: 0) as! NSDictionary
                
                let name = dicTeacher.object(forKey: "TeacherName")
                
                print(name)
                */
                
                // the todo object is a dictionary
                // so we just access the title using the "title" key
                // so check for a title and print it if we have one
                
                // print("The title is: " + todoTitle)
            } catch  {
                print("error trying to convert data to JSON")
                return
            }
        }
        
        task.resume()
    }

    func makePostCall()
    {
        let urlPath: String = "http://202.131.123.211/UdgamApi_v4/App_Services/UdgamService.asmx/GetAllTeacherData"
        let url = URL(string: urlPath)
        
        var urlRequest = URLRequest(url: url!)
        
        let postString = "StudentId=2011111" //"id=13&name=Jack"
        
        urlRequest.httpMethod = "POST"
        urlRequest.httpBody = postString.data(using: String.Encoding.utf8)
        
        
        // set up the session
        let config = URLSessionConfiguration.default
        let session = URLSession(configuration: config)
        
        let task = session.dataTask(with: urlRequest) { (data, response, error) in
            
            do {
                
                guard let getResponseDic = try JSONSerialization.jsonObject(with: data!, options: []) as? [String: AnyObject] else {
                    print("error trying to convert data to JSON")
                    return
                }
                // now we have the todo, let's just print it to prove we can access it
                
                print(getResponseDic as NSDictionary)
                
                
                // the todo object is a dictionary
                // so we just access the title using the "title" key
                // so check for a title and print it if we have one
                
                // print("The title is: " + todoTitle)
            } catch  {
                print("error trying to convert data to JSON")
                return
            }
            
            
            
            
        }
        
        task.resume()
        
        
    }
    
    func apiCallUsingSession()
    {
        let urlString = URL(string: "http://jsonplaceholder.typicode.com/users/1")
        if let url = urlString {
            let task = URLSession.shared.dataTask(with: url) { (data, response, error) in
                if error != nil {
                    print(error)
                } else {
                    if let usableData = data {
                        print(usableData) //JSONSerialization
                        
                        do{
                            let json = try JSONSerialization.jsonObject(with: usableData, options: []) as? [String : Any]
                            
                            print(json)
                            
                            if let street = json!["street"] as? String
                            {
                               print(street)
                                
                            }
                            
                        }catch
                        {
                            
                        }
                    }
                }
            }
            task.resume()
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
