//
//  studentTableViewCell.swift
//  May2018
//
//  Created by agilemac-74 on 04/06/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit

class studentTableViewCell: UITableViewCell {

    @IBOutlet var lblEmail: UILabel!
    @IBOutlet var lblLastName: UILabel!
    @IBOutlet var lblFirstName: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
