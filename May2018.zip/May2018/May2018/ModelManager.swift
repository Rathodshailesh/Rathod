//
//  ModelManager.swift
//  SwiftDemoApp
//
//  Created by agile on 18/06/16.
//  Copyright © 2016 agile. All rights reserved.
//

import UIKit
import FMDB

let sharedInstance = ModelManager()

class ModelManager: NSObject
{
    
    var database:FMDatabase? = nil
    
    var queue:FMDatabaseQueue? = nil
    
    
    class func getInstance() -> ModelManager
    {
        if(sharedInstance.database == nil)
        {
            let documentsURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            
            let fileURL = documentsURL.appendingPathComponent("AgileDB.sqlite" as String)
            
            sharedInstance.database = FMDatabase(path: fileURL.path)
            
            sharedInstance.queue = FMDatabaseQueue(path: fileURL.path)
            
            
        }
        
        return sharedInstance
    }
    
    func InsertData(name:String,lastName:String,email:String,city:String) -> Bool
    {
        
       
        
        
        //print(name)
        //print(marks)
        
        sharedInstance.database!.open()
        
        
        let isInserted = sharedInstance.database!.executeUpdate("INSERT INTO tbl_User (firstName, lastName,email,city) VALUES (?,?,?,?)", withArgumentsIn: [name,lastName,email,city]);
 
        print(sharedInstance.database!.lastErrorMessage())
        
        sharedInstance.database!.close()
 
        
        /*
        sharedInstance.queue?.inTransaction { db, rollback in
            do {
                try db.executeUpdate("INSERT INTO student (fName, email,mobileNumber) VALUES (?, ?,?)", values: [name,email,mobile])
                
                /*
                if whoopsSomethingWrongHappened {
                    rollback.pointee = true
                    return
                }
                */
                // etc ...
            } catch {
                rollback.pointee = true
                print(error)
            }
        }
        */
        return isInserted
    }
    
    func UpdateData(name:String,marks:String,rollNo:Int) -> Bool
    {
        sharedInstance.database!.open()
        
        
        let isUpdated = sharedInstance.database!.executeUpdate("UPDATE Tbluser SET firstName=?, marks=? WHERE id=?", withArgumentsIn: [name, marks, rollNo])
        sharedInstance.database!.close()
        return isUpdated
    }
    
    func getAllData() -> [[String:Any]]
    {
        sharedInstance.database!.open()
        
        var marrStudentInfo : [[String:Any]] = [[String:Any]]()
        
        let resultSet :FMResultSet! = sharedInstance.database!.executeQuery("SELECT * FROM tbl_User where id = ?", withArgumentsIn: ["1"])

        if (resultSet != nil)
        {
            while resultSet.next()
            {
                var studentInfo : [String:Any] = [String:Any]()
                
                
                let firstName = resultSet.string(forColumn: "firstName")
                
                let lastName = resultSet.string(forColumn: "lastName")
                
                let email = resultSet.string(forColumn: "email")
                
                let city = resultSet.string(forColumn: "city")
                
                let userId = resultSet.int(forColumn: "id")
                
                studentInfo = ["firstName":firstName!,"lastName":lastName!,"email":email!,"city":city!,"userId":userId]
                
                marrStudentInfo.append(studentInfo)
            }
        }
        
        sharedInstance.database!.close()
        return marrStudentInfo
        
    }
    
    func DeleteRecord(rollNo:Int) -> Bool
    {
        sharedInstance.database!.open()
        
        let isDeleted = sharedInstance.database!.executeUpdate("DELETE FROM Tbluser WHERE id=?", withArgumentsIn: [rollNo])
        
        sharedInstance.database!.close()
        
        return isDeleted
    }

    

    
    
   
}
